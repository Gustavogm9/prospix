import { FastifyPluginAsync, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { env } from '../../config/env.js';
import { logger } from '../../lib/logger.js';
import { encryptSecret } from '../../tenant/secrets-vault.js';
import crypto from 'crypto';

export const integrationsRoutes: FastifyPluginAsync = async (app) => {
  // GET /v1/tenant/integrations/google/oauth - Generate Google Calendar consent URL
  app.get('/google/oauth', async (req: FastifyRequest, reply: FastifyReply) => {
    if (!req.tenantId) {
      return reply.code(401).send({ error: 'Unauthorized', message: 'Tenant context is required' });
    }

    const tenantId = req.tenantId;

    // Generate CSRF state
    const state = crypto.randomBytes(16).toString('hex');
    
    // Store CSRF state in Redis for 10 minutes
    await redis.set(`google:oauth:${state}`, tenantId, 'EX', 600);

    const redirectUri = `${env.API_URL}/v1/tenant/integrations/google/callback`;
    const scopes = [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/calendar.events',
    ].join(' ');

    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` + new URLSearchParams({
      client_id: env.GOOGLE_CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: scopes,
      access_type: 'offline',
      prompt: 'consent',
      state: state,
    }).toString();

    logger.info({ tenantId, state }, 'Generated Google OAuth consent URL');
    return reply.send({ auth_url: authUrl });
  });

  // GET /v1/tenant/integrations/google/callback - Process Google Calendar OAuth callback
  app.get('/google/callback', async (req: FastifyRequest, reply: FastifyReply) => {
    const { code, state, error } = req.query as { code?: string; state?: string; error?: string };

    if (error) {
      logger.error({ error }, 'Google OAuth Callback returned error');
      return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=error&message=${encodeURIComponent(error)}`);
    }

    if (!code || !state) {
      logger.warn('Google OAuth Callback missing code or state');
      return reply.code(400).send({ error: 'Bad Request', message: 'Missing oauth code or state' });
    }

    // 1. Verify CSRF State
    const tenantId = await redis.get(`google:oauth:${state}`);
    if (!tenantId) {
      logger.warn({ state }, 'Google OAuth Callback state expired or invalid');
      return reply.code(400).send({ error: 'CSRF_FAILED', message: 'OAuth state is invalid or has expired' });
    }

    // Delete state to prevent replay attack
    await redis.del(`google:oauth:${state}`);

    // 2. Exchange authorization code for tokens
    try {
      const redirectUri = `${env.API_URL}/v1/tenant/integrations/google/callback`;
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: env.GOOGLE_CLIENT_ID,
          client_secret: env.GOOGLE_CLIENT_SECRET,
          code: code,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code',
        }),
      });

      if (!tokenRes.ok) {
        const errorText = await tokenRes.text();
        logger.error({ status: tokenRes.status, body: errorText }, 'Google Token Exchange failed');
        return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=token_exchange_failed`);
      }

      const tokenData = (await tokenRes.json()) as { refresh_token?: string; access_token: string };

      if (!tokenData.refresh_token) {
        logger.warn({ tenantId }, 'Google OAuth Callback did not return refresh token');
        // If Google didn't return a refresh token, check if we already have one
        const existingSecret = await prisma.tenantSecret.findUnique({
          where: { tenantId },
        });

        if (existingSecret?.googleOauthRefreshEncrypted) {
          logger.info({ tenantId }, 'Google OAuth Callback: Using pre-existing refresh token');
          return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=success`);
        }

        return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=missing_refresh_token`);
      }

      // 3. Encrypt & Save refresh token
      const encrypted = await encryptSecret(tokenData.refresh_token);

      await prisma.tenantSecret.upsert({
        where: { tenantId },
        create: {
          tenantId,
          googleOauthRefreshEncrypted: encrypted,
        },
        update: {
          googleOauthRefreshEncrypted: encrypted,
        },
      });

      logger.info({ tenantId }, 'Google Calendar OAuth integration configured successfully');
      
      // Redirect to tenant frontend dashboard success page
      return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=success`);
    } catch (err) {
      logger.error({ err, tenantId }, 'Error configuring Google Calendar integration');
      return reply.redirect(`${env.APP_URL}/dashboard/integrations?google=server_error`);
    }
  });
};

export default integrationsRoutes;
