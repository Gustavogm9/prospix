import { FastifyPluginAsync, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { logger } from '../../lib/logger.js';
import { createTenantQueue } from '../../lib/queue.js';
import { validateEvolutionWebhookSignature } from '../../integrations/evolution.js';
import { LeadStatus, ConversationStatus, MessageDeliveryStatus } from '@prisma/client';

export const evolutionWebhookRoutes: FastifyPluginAsync = async (app) => {
  
  // Hook to capture rawBody for HMAC checking
  app.addHook('preParsing', async (request: any, _reply, payload) => {
    let body = '';
    payload.on('data', (chunk) => {
      body += chunk;
    });
    payload.on('end', () => {
      request.rawBody = body;
    });
    return payload;
  });

  // Helper to resolve tenant and validate HMAC signature
  async function resolveTenantAndValidate(req: FastifyRequest, reply: FastifyReply, instanceName: string): Promise<string | null> {
    const secretRecord = await prisma.tenantSecret.findFirst({
      where: { evolutionInstanceName: instanceName },
    });

    if (!secretRecord) {
      logger.warn({ instanceName }, '⚠️ Webhook received for unconfigured Evolution API instance');
      reply.code(404).send({ error: 'Tenant secrets not found' });
      return null;
    }

    const tenantId = secretRecord.tenantId;

    // HMAC verification if webhook secret is configured
    const webhookSecret = secretRecord.evolutionWebhookSecret;
    if (webhookSecret) {
      const signature = req.headers['x-evolution-signature'] as string || req.headers['signature'] as string;
      const rawBody = (req as any).rawBody || JSON.stringify(req.body);
      
      const isValid = validateEvolutionWebhookSignature(rawBody, signature, webhookSecret);
      if (!isValid) {
        logger.error({ tenantId, instanceName }, '❌ Webhook HMAC signature verification failed');
        reply.code(401).send({ error: 'Unauthorized', message: 'HMAC signature is invalid' });
        return null;
      }
    }

    return tenantId;
  }

  // ── 1. POST /webhooks/evolution/inbound ─────────────────────────────────────
  app.post('/inbound', async (req: FastifyRequest, reply: FastifyReply) => {
    const body = req.body as any;
    const instance = body.instance;
    const event = body.event;

    if (!instance || event !== 'messages.upsert') {
      return reply.code(200).send({ success: true, ignored: true, reason: 'unsupported_event' });
    }

    const tenantId = await resolveTenantAndValidate(req, reply, instance);
    if (!tenantId) return; // Response handled by helper

    const messageData = body.data;
    if (!messageData || messageData.key?.fromMe) {
      // Ignora mensagens enviadas pelo próprio número do whatsapp (outbound)
      return reply.code(200).send({ success: true, ignored: true, reason: 'outbound_ignored' });
    }

    const remoteJid = messageData.key.remoteJid || '';
    const number = remoteJid.split('@')[0];
    const messageId = messageData.key.id;
    const pushName = messageData.pushName || 'Lead do WhatsApp';

    // Retrieve text message content
    const text = messageData.message?.conversation || messageData.message?.extendedTextMessage?.text || '';
    if (!text) {
      logger.info({ messageId }, '👻 Empty message content, ignoring (media or other)');
      return reply.code(200).send({ success: true, ignored: true, reason: 'empty_content' });
    }

    // 1. Idempotency Check: search if message was already registered
    const existingMsg = await prisma.message.findUnique({
      where: { whatsappMessageId: messageId },
    });

    if (existingMsg) {
      logger.info({ messageId }, '🔄 Duplicate webhook received (idempotency triggered)');
      return reply.code(200).send({ success: true, duplicate: true });
    }

    // 2. Fetch or create Lead
    let lead = await prisma.lead.findUnique({
      where: {
        tenantId_whatsapp: {
          tenantId,
          whatsapp: number,
        },
      },
    });

    if (!lead) {
      logger.info({ number, tenantId }, '🆕 Lead not found, creating in webhook dynamically');
      lead = await prisma.lead.create({
        data: {
          tenantId,
          whatsapp: number,
          name: pushName,
          source: 'MANUAL',
          status: LeadStatus.CONTACTED,
        },
      });
    }

    // 3. Fetch or create active Conversation
    let conversation = await prisma.conversation.findFirst({
      where: {
        tenantId,
        leadId: lead.id,
        status: ConversationStatus.ACTIVE,
      },
    });

    if (!conversation) {
      logger.info({ leadId: lead.id }, '🆕 Active conversation not found, creating a new one');
      conversation = await prisma.conversation.create({
        data: {
          tenantId,
          leadId: lead.id,
          status: ConversationStatus.ACTIVE,
          aiHandling: true,
        },
      });
    }

    // 4. Enqueue processing in process-inbound queue asynchronously
    const processQueue = createTenantQueue(tenantId, 'process-inbound');
    await processQueue.add('inbound-message', {
      tenant_id: tenantId,
      conversation_id: conversation.id,
      lead_id: lead.id,
      message_content: text,
      message_direction: 'INBOUND',
      whatsapp_message_id: messageId,
      push_name: pushName,
    });

    logger.info({ tenantId, conversationId: conversation.id, messageId }, '📥 Inbound message queued for processing');
    return reply.code(200).send({ success: true, queued: true });
  });

  // ── 2. POST /webhooks/evolution/status ──────────────────────────────────────
  app.post('/status', async (req: FastifyRequest, reply: FastifyReply) => {
    const body = req.body as any;
    const instance = body.instance;
    const event = body.event;

    if (!instance || event !== 'messages.update') {
      return reply.code(200).send({ success: true, ignored: true });
    }

    const tenantId = await resolveTenantAndValidate(req, reply, instance);
    if (!tenantId) return;

    const statusData = body.data;
    if (!statusData || !statusData.key) {
      return reply.code(200).send({ success: true, ignored: true });
    }

    const messageId = statusData.key.id;
    const rawStatus = statusData.status;

    // Map Evolution status to message Delivery Status
    let status: MessageDeliveryStatus = MessageDeliveryStatus.SENT;
    if (rawStatus === 'DELIVERED') {
      status = MessageDeliveryStatus.DELIVERED;
    } else if (rawStatus === 'READ') {
      status = MessageDeliveryStatus.READ;
    } else if (rawStatus === 'ERROR' || rawStatus === 'FAILED') {
      status = MessageDeliveryStatus.FAILED;
    }

    // Search and update message
    const msg = await prisma.message.findUnique({
      where: { whatsappMessageId: messageId },
    });

    if (msg) {
      await prisma.message.update({
        where: { id: msg.id },
        data: {
          deliveryStatus: status,
          deliveredAt: status === MessageDeliveryStatus.DELIVERED ? new Date() : undefined,
          readAt: status === MessageDeliveryStatus.READ ? new Date() : undefined,
          failedReason: status === MessageDeliveryStatus.FAILED ? 'Evolution API delivery failed' : undefined,
        },
      });
      logger.info({ messageId, status }, '✅ Message delivery status updated');
    }

    return reply.code(200).send({ success: true });
  });

  // ── 3. POST /webhooks/evolution/instance ────────────────────────────────────
  app.post('/instance', async (req: FastifyRequest, reply: FastifyReply) => {
    const body = req.body as any;
    const instance = body.instance;
    const event = body.event;

    if (!instance) {
      return reply.code(200).send({ success: true, ignored: true });
    }

    const tenantId = await resolveTenantAndValidate(req, reply, instance);
    if (!tenantId) return;

    logger.info({ tenantId, event, body }, '🔌 Evolution Instance status webhook received');

    // If quality rating is present in payload, cache it in Redis
    if (body.data?.quality_rating || body.quality_rating) {
      const rating = body.data?.quality_rating || body.quality_rating;
      const qualityRatingKey = `whatsapp:quality:${tenantId}`;
      await redis.set(qualityRatingKey, rating.toLowerCase());
      logger.info({ tenantId, rating }, '📈 WhatsApp Quality Rating cached in Redis');
    }

    return reply.code(200).send({ success: true });
  });
};
export default evolutionWebhookRoutes;
