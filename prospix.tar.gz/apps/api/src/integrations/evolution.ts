import { Result } from '@prospix/shared-types';
import { ResultHelper } from '../lib/result.js';
import { logger } from '../lib/logger.js';
import crypto from 'crypto';

export interface CheckPhoneResult {
  exists: boolean;
  jid?: string;
}

export interface SendMessageResult {
  messageId: string;
}

export interface ConnectionStateResult {
  state: 'open' | 'connecting' | 'close';
}

/**
 * Validate HMAC signature sent by Evolution API Webhooks.
 */
export function validateEvolutionWebhookSignature(payload: string, signature: string, secret: string): boolean {
  try {
    const hmac = crypto.createHmac('sha256', secret);
    const computed = hmac.update(payload).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(computed, 'hex'), Buffer.from(signature, 'hex'));
  } catch (_) {
    return false;
  }
}

/**
 * Legacy single helper for checkPhone.
 */
export async function checkPhone(params: {
  phone: string;
  instanceName: string;
  baseUrl: string;
  apiKey: string;
}): Promise<Result<CheckPhoneResult>> {
  const client = createEvolutionClient();
  const res = await client.checkNumbers({
    instance: params.instanceName,
    baseUrl: params.baseUrl,
    apiKey: params.apiKey,
    numbers: [params.phone],
  });
  if (!res.ok) return ResultHelper.failure(res.error);
  const first = res.value[0];
  if (!first) {
    return ResultHelper.failure({
      code: 'VALIDATION_ERROR',
      message: 'No result returned for phone number check',
    });
  }
  return ResultHelper.success(first);
}

/**
 * Evolution API Client Factory
 */
export function createEvolutionClient() {
  return {
    async sendText(params: {
      instance: string;
      baseUrl: string;
      apiKey: string;
      number: string;
      text: string;
    }): Promise<Result<SendMessageResult>> {
      const cleanUrl = params.baseUrl.endsWith('/') ? params.baseUrl.slice(0, -1) : params.baseUrl;
      const url = `${cleanUrl}/message/sendText/${params.instance}`;

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': params.apiKey,
          },
          body: JSON.stringify({
            number: params.number,
            options: { delay: 1200, presence: 'composing' },
            textMessage: { text: params.text },
          }),
        });

        if (!response.ok) {
          const errTxt = await response.text();
          logger.error({ status: response.status, body: errTxt }, 'Evolution API sendText failed');
          return ResultHelper.failure({
            code: 'EXTERNAL_SERVICE_DOWN',
            message: `Evolution API sendText returned ${response.status}`,
          });
        }

        const data = (await response.json()) as any;
        return ResultHelper.success({
          messageId: data.key?.id || `mock_${Date.now()}`,
        });
      } catch (err: any) {
        logger.error({ err }, 'Exception calling Evolution API sendText');
        return ResultHelper.failure({
          code: 'EXTERNAL_SERVICE_DOWN',
          message: err.message || 'Failed to send message via Evolution API',
        });
      }
    },

    async checkNumbers(params: {
      instance: string;
      baseUrl: string;
      apiKey: string;
      numbers: string[];
    }): Promise<Result<CheckPhoneResult[]>> {
      const cleanUrl = params.baseUrl.endsWith('/') ? params.baseUrl.slice(0, -1) : params.baseUrl;
      const url = `${cleanUrl}/chat/whatsappNumbers/${params.instance}`;

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': params.apiKey,
          },
          body: JSON.stringify({ numbers: params.numbers }),
        });

        if (!response.ok) {
          return ResultHelper.failure({
            code: 'EXTERNAL_SERVICE_DOWN',
            message: `Evolution API checkNumbers returned ${response.status}`,
          });
        }

        const data = (await response.json()) as any[];
        const mapped = data.map((item) => ({
          exists: item.exists ?? false,
          jid: item.jid,
        }));
        return ResultHelper.success(mapped);
      } catch (err: any) {
        return ResultHelper.failure({
          code: 'EXTERNAL_SERVICE_DOWN',
          message: err.message || 'Failed to check numbers via Evolution API',
        });
      }
    },

    async getConnectionState(params: {
      instance: string;
      baseUrl: string;
      apiKey: string;
    }): Promise<Result<ConnectionStateResult>> {
      const cleanUrl = params.baseUrl.endsWith('/') ? params.baseUrl.slice(0, -1) : params.baseUrl;
      const url = `${cleanUrl}/instance/connectionState/${params.instance}`;

      try {
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'apikey': params.apiKey,
          },
        });

        if (!response.ok) {
          return ResultHelper.failure({
            code: 'EXTERNAL_SERVICE_DOWN',
            message: `Evolution API connectionState returned ${response.status}`,
          });
        }

        const data = (await response.json()) as any;
        return ResultHelper.success({
          state: data.instance?.state === 'open' ? 'open' : 'close',
        });
      } catch (err: any) {
        return ResultHelper.failure({
          code: 'EXTERNAL_SERVICE_DOWN',
          message: err.message || 'Failed to get connection state via Evolution API',
        });
      }
    },
  };
}
